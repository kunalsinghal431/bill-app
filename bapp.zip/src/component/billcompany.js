import { useState } from "react";
import { Input } from "./inputdetail";
export const Billcompany= ()=>{
const [Billcompany, setBillcompany] = useState("");
const bill_detail=(evt)=>{
setBillcompany(evt.target.value);
}
return <Input val={Billcompany} fn={bill_detail} labelValue= "Enter Billing Company Name" />
}
