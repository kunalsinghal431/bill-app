import { useState } from "react";
import { Input } from "./inputdetail";
export const Clientdetail= ()=>{
const [Clientdetail, setClientdetail] = useState("");
const client_detail=(evt)=>{
setClientdetail(evt.target.value);
}
return <Input val={Clientdetail} fn={client_detail} labelValue= "Enter Client Details" />
}
