import './App.css';
import { Page } from './component/page';
function App() {
  return (
    <Page/>
      );
}

export default App;
